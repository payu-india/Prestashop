<?php

class PayubizCartdataModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $context = Context::getContext();
        $customer = $context->customer;

        // Get PayUBiz module instance (should be an object)
        $module = Module::getInstanceByName('payubiz'); 

        if (!Validate::isLoadedObject($module)) {
            die('Error: Payment module not found.');
        }

        // Ensure PayUBiz is an available payment method
        $paymentAvailable = false;
        foreach (Module::getPaymentModules() as $paymentModule) {
            if ($paymentModule['name'] == 'payubiz') {
                $paymentAvailable = true;
                break;
            }
        }

        if (!$paymentAvailable) {
            die('Error: PayUBiz is not an active payment method.');
        }
        

        // Check if order already exists
        $cart_id = (int) $_REQUEST['txnid'];
        if (Order::getIdByCartId($cart_id)) {
            die('Error: Order already exists for this cart.');
        }
        $id_currency = (int) $context->cart->id_currency ?: (int) Configuration::get('PS_CURRENCY_DEFAULT');

        $order_create_data = $module->validateOrder(
            (int) $cart_id,
            (int) Configuration::get('PS_OS_WAITING_PAYMENT') ?: 14, 
            (float) $_REQUEST['amount'],
            'PayUBiz',
            null,
            [],
            $id_currency, // ✅ Corrected currency retrieval
            false,
            $customer->secure_key
        );


        // Redirect to PayU payment gateway
        $mode = Configuration::get('PAYUBIZ_MODE');
        $payu_url = ($mode == 'sandbox') 
            ? 'https://test.payu.in/_payment' 
            : 'https://secure.payu.in/_payment';

        echo '<form id="payuForm" action="' . $payu_url . '" method="post">';
        foreach ($_REQUEST as $key => $value) {
            if (is_array($value)) {
                continue;
            }
            echo '<input type="hidden" name="' . htmlspecialchars($key, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '">';
        }
        echo '</form>';
        echo '<script>document.getElementById("payuForm").submit();</script>';
        exit;
    }
}

