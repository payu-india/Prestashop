<?php
class PayubizPaymentstatusModuleFrontController extends ModuleFrontController
{
    /** @var bool Disable template rendering */
    public $ajax = true;

    public function display()
    {
        if (php_sapi_name() !== 'cli') {
            $this->ajaxRender(json_encode(['error' => 'Forbidden call.']));
            return;
        }

        // Process payments
        $this->processPaymentStatus();
    }

    private function processPaymentStatus()
    {
        $status_name = 'Waiting for payment';
        $sql = "SELECT id_order_state FROM " . _DB_PREFIX_ . "order_state_lang WHERE name = '" . pSQL($status_name) . "'";
        $id_order_state = Db::getInstance()->getValue($sql);

        if (!$id_order_state) {
            $this->ajaxRender(json_encode(['error' => 'Order status not found.']));
            return;
        }

        // Fetch orders with pending status
        $query = "SELECT o.id_cart FROM " . _DB_PREFIX_ . "orders o WHERE o.current_state = " . (int)$id_order_state;
        $orders = Db::getInstance()->executeS($query);

        if (!$orders) {
            $this->ajaxRender(json_encode(['error' => 'No transactions found.']));
            return;
        }

        // Get transaction details
        $transactions = $this->getMultipleTransactionDetails(array_column($orders, 'id_cart'));

        $this->ajaxRender(json_encode([
            'status' => 'success',
            'count' => count($transactions) . ' transactions processed',
            'transactions' => $transactions
        ]));
    }

    private function getMultipleTransactionDetails($txn_ids)
    {
        $merchant_key = Configuration::get('PAYUBIZ_KEY');
        $salt = Configuration::get('PAYUBIZ_SALT');
        $command = "verify_payment";
        
        $mode = Configuration::get('PAYUBIZ_MODE');
        $action = ($mode === 'sandbox') ? 'https://test.payu.in/merchant/postservice' : 'https://info.payu.in/merchant/postservice.php';
    
        $multiCurl = [];
        $results = [];
        $mh = curl_multi_init();
    
        foreach ($txn_ids as $txnid) {
            $hash_string = $merchant_key . '|' . $command . '|' . $txnid . '|' . $salt;
            $hash = hash("sha512", $hash_string);
    
            $postData = http_build_query([
                'key' => $merchant_key,
                'command' => $command,
                'var1' => $txnid,
                'hash' => $hash
            ]);
    
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $action,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
            ]);
    
            $multiCurl[$txnid] = $ch;
            curl_multi_add_handle($mh, $ch);
        }
    
        do {
            $status = curl_multi_exec($mh, $active);
        } while ($status === CURLM_CALL_MULTI_PERFORM || $active);
    
        foreach ($multiCurl as $txnid => $ch) {
            $response = curl_multi_getcontent($ch);
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
    
            $transaction_data = @unserialize($response) ?: json_decode($response, true);
            $status = $transaction_data['transaction_details'][$txnid]['status'] ?? 'Not Found';
    
            $order_id = Order::getIdByCartId($txnid);
    
            if (!$order_id) {
                $results[] = [
                    'Transaction ID' => $txnid,
                    'Status' => 'Error: Order not found for this cart.'
                ];
                continue;
            }
    
            $order = new Order($order_id);
            $history = new OrderHistory();
            $history->id_order = $order->id;
    
            // 🔥 Determine the order status and message
            if ($status === 'failure') {
                $order_status = Configuration::get('PAYUBIZ_ID_ORDER_FAILED');
                $message = 'Order marked as failed.';
            } elseif ($status === 'success') {
                $order_status = Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS');
                $message = 'Order marked as successful.';
            } elseif ($status === 'pending') {
                $order_status = (int) Configuration::get('PS_OS_WAITING_PAYMENT') ?: 14;
                $message = 'Order status updated to pending.';
            } else {
                $order_status = null;
                $message = 'Unknown status.';
            }
    
            if ($order_status) {
                $history->changeIdOrderState($order_status, $order->id);
                $history->addWithemail(true);
    
                // ✅ Store payment details if the transaction is successful
                if ($status === 'success') {
                    $existingPayment = Db::getInstance()->getValue(
                        'SELECT id_order_payment FROM ' . _DB_PREFIX_ . 'order_payment 
                         WHERE transaction_id = "' . pSQL($txnid) . '" 
                         AND order_reference = "' . pSQL($order->reference) . '"'
                    );
    
                    if (!$existingPayment) {
                        $currency = new Currency($order->id_currency);
                        $amount = (float)$transaction_data['transaction_details'][$txnid]['net_amount_debit'] ?? 0.00;
    
                        $payment = new OrderPayment();
                        $payment->order_reference = $order->reference;
                        $payment->id_currency = (int)$currency->id;
                        $payment->amount = $amount;
                        $payment->payment_method = 'payubiz';
                        $payment->transaction_id = $txnid;
                        $payment->date_add = date('Y-m-d H:i:s');
    
                        // ✅ Store Card Details
                        $payment->card_number = $transaction_data['transaction_details'][$txnid]['cardnum'] ?? 'Not defined';
                        $payment->card_type = $transaction_data['transaction_details'][$txnid]['card_type'] ?? 'Not defined';
                        $payment->expiration_date = $transaction_data['transaction_details'][$txnid]['card_expiry'] ?? 'Not defined';
                        $payment->cardholder_name = $transaction_data['transaction_details'][$txnid]['card_name'] ?? 'Not defined';
    
                        $payment->save();
    
                        // Link payment to order
                        if (!$order->getOrderPayments()) {
                            $order->addOrderPayment($amount, 'payubiz', $txnid);
                        }
                    } else {
                        PrestaShopLogger::addLog("PayUBiz: Duplicate payment detected for Transaction ID - " . $txnid, 1);
                    }
                }
            }
    
            $results[] = [
                'Transaction ID' => $txnid,
                'Status' => $status,
                'Message' => $message
            ];
        }
    
        curl_multi_close($mh);
        return $results;
    }
    
}

