<?php
class PayubizFailureModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        
        // Retrieve error message from cookie
        $errorMsg = '';
        if (!empty($this->context->cookie->payubiz_error)) {
            $errorMsg = $this->context->cookie->payubiz_error;
            unset($this->context->cookie->payubiz_error); // Clear message after displaying
            $this->context->cookie->write();
        }

        // Assign error message to template
        $this->context->smarty->assign(array(
            'message' => $errorMsg
        ));

        // Set failure template
        $this->setTemplate('module:payubiz/views/templates/front/failure.tpl');

        // Auto-redirect to cart page after 5 seconds
        echo '<script>
                setTimeout(function() {
                    window.location.href = "index.php?controller=order&step=1";
                }, 3000);
              </script>';
    }
}
