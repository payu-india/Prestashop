<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.7.0
 */
class PayubizValidationModuleFrontController extends ModuleFrontController
{
    public $warning = '';
    public $message = '';

    public function initContent()
    {  
        parent::initContent();
        // // Retrieve error message from cookie
        // $errorMsg = '';
        // if (!empty($this->context->cookie->payubiz_error)) {
        //     $errorMsg = $this->context->cookie->payubiz_error;
        //     unset($this->context->cookie->payubiz_error); // Clear message after displaying
        //     $this->context->cookie->write();
        // }
    
        $this->context->smarty->assign(array(
            // 'warning' => $this->warning,
            // 'message' => $this->message,
           'message' => $errorMsg // Assign error message to 'message' variable
        ));              	
    
        $this->setTemplate('module:payubiz/views/templates/front/validation.tpl');  
    }
  
    public function postProcess()
    {
        $context = Context::getContext();
		$customer = $context->customer;

		// Retrieve cart ID from request
		$cart_id = (int) Tools::getValue('txnid'); // Get cart ID from request
        
		// Load cart using txnid (assuming txnid is the cart ID)
		if ($cart_id > 0) {
			$cart = new Cart($cart_id);
			$context->cart = $cart;
		} else {
			Tools::redirect('index.php?controller=order&step=1');
		}

		// Validate cart existence
		if (!$cart->id) {
			Tools::redirect('index.php?controller=order&step=1');
		}
        $cart->id = $cart_id; 
		$customer->id = $cart->id_customer;
		$customer->secure_key = $cart->secure_key;


		// Debugging: Check if cart and customer exist
		PrestaShopLogger::addLog("PayUBiz Debug: Cart ID - " . ($cart->id ?: 'NULL') . ", Customer ID - " . ($customer->id ?: 'NULL'), 1);

		// Fix: Retrieve cart manually if missing
		if (!$cart->id) {
			$cart_id = (int) Tools::getValue('id_cart');
			if ($cart_id > 0) {
				$cart = new Cart($cart_id);
				$context->cart = $cart;
				PrestaShopLogger::addLog("PayUBiz Debug: Manually Loaded Cart ID - " . $cart->id, 1);
			}
		}
        
		// Fix: Ensure cart is linked to the customer
		if ($cart->id_customer == 0 && $customer->id) {
			$cart->id_customer = $customer->id;
			$cart->update();
			
			PrestaShopLogger::addLog("PayUBiz Debug: Updated Cart with Customer ID - " . $customer->id, 1);
		}

		// Debugging: Show final cart and customer values
		

		if (!$cart->id || !$customer->id) {
			PrestaShopLogger::addLog("PayUBiz Error: Missing Cart or Customer Data", 3);
			Tools::redirect('index.php?controller=order&step=1');
		}

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        // Check that this payment option is still available
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'payubiz') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            $this->warning = 'This payment method is not available.';
            $this->message = 'Contact Administrator for available payment methods.';
            return;
        }

        $customer = new Customer($cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $currency = $context->currency;
        
        // Check if we have PayUBiz response
        $payemntType = 0;
        if (isset($_REQUEST['key'])) {
            $payemntType = 1;
        } else {
            $this->warning = "Payment error - Invalid response received from payment gateway";
            $this->message = "Payment gateway did not respond in proper format.";
            return;
        }

        if ($payemntType == 1) {
            // Process PayUBiz response
            $postdata = $_REQUEST;
            $payu_key = Configuration::get('PAYUBIZ_KEY');
            $payu_salt = Configuration::get('PAYUBIZ_SALT');
            
            if (isset($postdata['key']) && ($postdata['key'] == $payu_key)) {
                $cart_id = $cart->id;
                $txnid = $postdata['txnid'];
                $amount = $postdata['amount'];
                $productInfo = $postdata['productinfo'];
                $firstname = $postdata['firstname'];
                $email = $postdata['email'];
                $udf5 = $postdata['udf5'];
                $keyString = $payu_key . '|' . $txnid . '|' . $amount . '|' . $productInfo . '|' . $firstname . '|' . $email . '|||||' . $udf5 . '|||||';
                $reverseKeyArray = array_reverse(explode("|", $keyString));
                $reverseKeyString = implode("|", $reverseKeyArray);

                if (isset($postdata['status']) && $postdata['status'] == 'success') {
                    $saltString = $payu_salt . '|' . $postdata['status'] . '|' . $reverseKeyString;
                    $sentHashString = strtolower(hash('sha512', $saltString));
                    $responseHashString = $postdata['hash'];
                    
                    if ($sentHashString == $responseHashString) {
                        $status = Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS');
                        $responseMsg = "Thank you for shopping with us. Your transaction is successful.";
                    } else {
                        $status = Configuration::get('PAYUBIZ_ID_ORDER_FAILED');
                        $responseMsg = "Payment failed due to hash mismatch.";
                        $this->message = "Possible attempt to tamper with payment.";
                    }
                } else {
                    $status = Configuration::get('PAYUBIZ_ID_ORDER_FAILED');
                    $responseMsg = "Payment was cancelled or declined.";
                    $this->message = "Payment gateway responded - " . $postdata['field9'];
                }
            }
        }

        PrestaShopLogger::addLog("PayUBiz: Created Order for Cart ID - " . $cart->id, 1, null, 'payubiz', (int) $cart->id, true);

        $order_id = Order::getIdByCartId($cart->id);

        if (!$order_id) {
            die('Error: Order not found for this cart.');
        }


        // Get Order Object
        $order = new Order($order_id);
        // Update Order Status
        $history = new OrderHistory();
        $history->id_order = $order->id;
        $history->changeIdOrderState($status, $order->id);
        $history->addWithemail(true);
        

        // 🔥 Ensure payment is recorded in the order
        if ($status == Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS')) {
            // Check if payment already exists for this transaction ID
            $existingPayment = Db::getInstance()->getValue(
                'SELECT id_order_payment FROM ' . _DB_PREFIX_ . 'order_payment WHERE transaction_id = "' . pSQL($postdata['txnid']) . '" AND order_reference = "' . pSQL($order->reference) . '"'
            );

            if (!$existingPayment) { // ✅ Only add payment if it doesn't already exist
                $payment = new OrderPayment();
                $payment->order_reference = $order->reference;
                $payment->id_currency = (int) $currency->id;
                $payment->amount = (float) $amount;
                $payment->payment_method = 'payubiz';
                $payment->transaction_id = $postdata['txnid'];
                $payment->date_add = date('Y-m-d H:i:s');
                // ✅ Store Card Details
                $payment->card_number = isset($postdata['cardnum']) ? $postdata['cardnum'] : 'Not defined';
                $payment->card_type = isset($postdata['card_type']) ? $postdata['card_type'] : 'Not defined';
                $payment->expiration_date = isset($postdata['card_expiry']) ? $postdata['card_expiry'] : 'Not defined';
                $payment->cardholder_name = isset($postdata['card_name']) ? $postdata['card_name'] : 'Not defined';

                $payment->save();

                // Link payment to order
                if (!$order->getOrderPayments()) { // ✅ Prevent duplicate linking
                    $order->addOrderPayment($amount, 'payubiz', $postdata['txnid']);
                }
            } else {
                PrestaShopLogger::addLog("PayUBiz: Duplicate payment detected for Transaction ID - " . $postdata['txnid'], 1);
            }
        }




        // $this->module->validateOrder((int) $cart->id, $status, (float) $amount, "payubiz", null, null, null, false, $customer->secure_key);
        
        if ($status == Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS')) {			
            Tools::redirect('index.php?controller=order-confirmation&id_cart=' . (int) $cart->id . '&id_module=' . (int) $this->module->id . '&id_order=' . $this->module->currentOrder . '&key=' . $customer->secure_key);
        } else {
            // $this->warning = $responseMsg;
            // Tools::redirect('index.php?controller=order&step=1');
           // Store error message in cookie
           $responseMsg = "Payment Failed: " . $responseMsg;
           $this->context->cookie->__set('payubiz_error', $responseMsg);
           $this->context->cookie->write();
           
           // Redirect to the failure page
           Tools::redirect($this->context->link->getModuleLink('payubiz', 'failure'));
           
        }
    }
}

// class PayubizValidationModuleFrontController extends ModuleFrontController
// {
//     public $warning = '';
//     public $message = '';

//     public function initContent()
//     {  
//         parent::initContent();
    
//         $this->context->smarty->assign(array(
//             'message' => $this->message
//         ));              
    
//         $this->setTemplate('module:payubiz/views/templates/front/validation.tpl');  
//     }
  
//     public function postProcess()
//     {
//         $context = Context::getContext();
//         $customer = $context->customer;

//         $cart_id = (int) Tools::getValue('txnid');
        
//         if ($cart_id > 0) {
//             $cart = new Cart($cart_id);
//             $context->cart = $cart;
//         } else {
//             Tools::redirect('index.php?controller=order&step=1');
//         }

//         if (!$cart->id) {
//             Tools::redirect('index.php?controller=order&step=1');
//         }

//         $customer->id = $cart->id_customer;
//         $customer->secure_key = $cart->secure_key;

//         PrestaShopLogger::addLog("PayUBiz Debug: Cart ID - " . ($cart->id ?: 'NULL') . ", Customer ID - " . ($customer->id ?: 'NULL'), 1);

//         if (!$cart->id || !$customer->id) {
//             PrestaShopLogger::addLog("PayUBiz Error: Missing Cart or Customer Data", 3);
//             Tools::redirect('index.php?controller=order&step=1');
//         }

//         if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
//             Tools::redirect('index.php?controller=order&step=1');
//         }

//         $authorized = false;
//         foreach (Module::getPaymentModules() as $module) {
//             if ($module['name'] == 'payubiz') {
//                 $authorized = true;
//                 break;
//             }
//         }

//         if (!$authorized) {
//             $this->warning = 'This payment method is not available.';
//             $this->message = 'Contact Administrator for available payment methods.';
//             return;
//         }

//         $customer = new Customer($cart->id_customer);
//         if (!Validate::isLoadedObject($customer)) {
//             Tools::redirect('index.php?controller=order&step=1');
//         }

//         $currency = $context->currency;
        
//         $payemntType = 0;
//         if (isset($_REQUEST['key'])) {
//             $payemntType = 1;
//         } else {
//             $this->warning = "Payment error - Invalid response received from payment gateway";
//             $this->message = "Payment gateway did not respond in proper format.";
//             return;
//         }

//         if ($payemntType == 1) {
//             $postdata = $_REQUEST;
//             $payu_key = Configuration::get('PAYUBIZ_KEY');
//             $payu_salt = Configuration::get('PAYUBIZ_SALT');
            
//             if (isset($postdata['key']) && ($postdata['key'] == $payu_key)) {
//                 $cart_id = $cart->id;
//                 $txnid = $postdata['txnid'];
//                 $amount = $postdata['amount'];
//                 $productInfo = $postdata['productinfo'];
//                 $firstname = $postdata['firstname'];
//                 $email = $postdata['email'];
//                 $udf5 = $postdata['udf5'];
//                 $keyString = $payu_key . '|' . $txnid . '|' . $amount . '|' . $productInfo . '|' . $firstname . '|' . $email . '|||||' . $udf5 . '|||||';
//                 $reverseKeyArray = array_reverse(explode("|", $keyString));
//                 $reverseKeyString = implode("|", $reverseKeyArray);

//                 if (isset($postdata['status']) && $postdata['status'] == 'success') {
//                     $saltString = $payu_salt . '|' . $postdata['status'] . '|' . $reverseKeyString;
//                     $sentHashString = strtolower(hash('sha512', $saltString));
//                     $responseHashString = $postdata['hash'];
                    
//                     if ($sentHashString == $responseHashString) {
//                         $status = Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS');
//                         $responseMsg = "Thank you for shopping with us. Your transaction is successful.";
//                     } else {
//                         $status = Configuration::get('PAYUBIZ_ID_ORDER_FAILED');
//                         $responseMsg = "Payment failed due to hash mismatch.";
//                         $this->message = "Possible attempt to tamper with payment.";
//                     }
//                 } else {
//                     $status = Configuration::get('PAYUBIZ_ID_ORDER_FAILED');
//                     $responseMsg = "Payment was cancelled or declined.";
//                     $this->message = "Payment gateway responded - " . $postdata['field9'];
//                 }
//             }
//         }

//         PrestaShopLogger::addLog("PayUBiz: Created Order for Cart ID - " . $cart->id, 1, null, 'payubiz', (int) $cart->id, true);

//         $order_id = Order::getIdByCartId($cart->id);

//         if (!$order_id) {
//             die('Error: Order not found for this cart.');
//         }

//         $order = new Order($order_id);
//         $history = new OrderHistory();
//         $history->id_order = $order->id;
//         $history->changeIdOrderState($status, $order->id);
//         $history->addWithemail(true);

//         if ($status == Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS')) {
//             $existingPayment = Db::getInstance()->getValue(
//                 'SELECT id_order_payment FROM ' . _DB_PREFIX_ . 'order_payment WHERE transaction_id = "' . pSQL($postdata['txnid']) . '" AND order_reference = "' . pSQL($order->reference) . '"'
//             );

//             if (!$existingPayment) {
//                 $payment = new OrderPayment();
//                 $payment->order_reference = $order->reference;
//                 $payment->id_currency = (int) $currency->id;
//                 $payment->amount = (float) $amount;
//                 $payment->payment_method = 'payubiz';
//                 $payment->transaction_id = $postdata['txnid'];
//                 $payment->date_add = date('Y-m-d H:i:s');
//                 $payment->card_number = isset($postdata['cardnum']) ? $postdata['cardnum'] : 'Not defined';
//                 $payment->card_type = isset($postdata['card_type']) ? $postdata['card_type'] : 'Not defined';
//                 $payment->expiration_date = isset($postdata['card_expiry']) ? $postdata['card_expiry'] : 'Not defined';
//                 $payment->cardholder_name = isset($postdata['card_name']) ? $postdata['card_name'] : 'Not defined';

//                 $payment->save();

//                 if (!$order->getOrderPayments()) {
//                     $order->addOrderPayment($amount, 'payubiz', $postdata['txnid']);
//                 }
//             }
//         }

//         // **Fix: Ensure Cookies Are Set Properly**
//         $this->context->cookie->id_cart = (int) $cart->id;
//         $this->context->cookie->id_customer = (int) $customer->id;
//         $this->context->cookie->secure_key = $customer->secure_key;
//         $this->context->cookie->write();

//         // **Fix: Use the correct order ID for redirection**
//         Tools::redirect($this->context->link->getPageLink('order-confirmation', true, (int) $this->context->language->id, [
//             'id_cart' => (int) $cart->id,
//             'id_module' => (int) $this->module->id,
//             'id_order' => (int) $order->id,
//             'key' => $customer->secure_key
//         ]));
//     }
// }



