<?php /* Prestashop payment module for PayUBiz */ ?>
<?php 	
error_reporting(E_ALL);	

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
	exit;
}

class payubiz extends PaymentModule
{
	private $_html = '';
	private $_postErrors = array();

	private $_title;
	
	function __construct()
	{		
		$this->name = 'payubiz';		
		$this->tab = 'payments_gateways';		
		$this->version = 1.7;
		$this->author = 'payubiz.in';
				
		$this->bootstrap = true;			
		parent::__construct();		
			
		$this->displayName = $this->trans('PayUBiz', array(), 'Modules.payubiz.Admin');
		$this->description = $this->trans('Accept payments by PayUBiz', array(), 'Modules.Payubiz.Admin');
		$this->confirmUninstall = $this->trans('Are you sure you want to delete these details?', array(), 'Modules.Payubiz.Admin');
		$this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
						
		$this->_title = "PayUBiz";
		
		$this->page = basename(__FILE__, '.php');		
					
	}	
	
	
	public function install()
	{
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state` ( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`, `module_name`)	VALUES	(0, 0, \'#33FF99\', 0, 1, 0, \'payubiz\');');
		$id_order_state = (int) Db::getInstance()->Insert_ID();
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES ('.$id_order_state.', 1, \'Payment accepted\', \'payment\')');
		Configuration::updateValue('PAYUBIZ_ID_ORDER_SUCCESS', $id_order_state);			
		unset($id_order_state);
				
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state`( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`, `module_name`) VALUES (0, 0, \'#33FF99\', 0, 1, 0, \'payubiz\');');
		$id_order_state = (int) Db::getInstance()->Insert_ID();
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES ('.$id_order_state.', 1, \'Payment Failed\', \'payment\')');
		Configuration::updateValue('PAYUBIZ_ID_ORDER_FAILED', $id_order_state);		
		unset($id_order_state);
		
		return parent::install()
        && $this->registerHook('paymentOptions');
        // && $this->registerHook('actionValidateOrder');
	
	}

	public function uninstall()
	{
		
		Db::getInstance()->Execute('DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` WHERE id_order_state = '.Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS').' and id_lang = 1' );
		Db::getInstance()->Execute('DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang`  WHERE id_order_state = '.Configuration::get('PAYUBIZ_ID_ORDER_FAILED').' and id_lang = 1');

		return Configuration::deleteByName('PAYUBIZ_MODE')
			&& Configuration::deleteByName('PAYUBIZ_KEY')
			&& Configuration::deleteByName('PAYUBIZ_SALT')
			&& parent::uninstall();		
	}
    
	public function hookPaymentOptions($params)
	{	
		
		if (!$this->active) {
			return;
		}

		// Get the cart object
		$cart = $params['cart'];
		$link = $this->context->link->getModuleLink('payubiz', 'cartdata'); // Custom controller link

		$newOption = new PaymentOption();
		$newOption->setCallToActionText($this->l($this->_title))
			->setAction($link) // Redirects to custom controller first
			->setInputs($this->payuInput()) // Hidden form inputs
			->setAdditionalInformation($this->context->smarty->fetch('module:payubiz/payubiz.tpl'));

		return [$newOption];
	}

	// public function hookActionValidateOrder($params)
	// {
	// 	$order = $params['order'];
	// 	$cart = $params['cart'];

	// 	if (!$order || !$cart) {
	// 		return;
	// 	}

	// 	// Example: Log order details
	// 	PrestaShopLogger::addLog('New order placed: Order ID - ' . (int) $order->id);

	// 	// Example: Send API call to an external system
	// 	// $this->sendOrderToExternalSystem($order);

	// 	// Example: Update custom order status
	// 	if ($order->module == 'payubiz') {
	// 		// PS_OS_PAYMENT
	// 		$order->setCurrentState(Configuration::get('PS_OS_WAITING_PAYMENT'));
	// 	}
	// }



	
	private function _postValidation()
	{
		if (Tools::isSubmit('btnSubmit')) {
			
			if (!Tools::getValue('PAYUBIZ_MODE')) {
				$this->_postErrors[] = $this->trans('Gateway mode is required.', array(), 'Modules.Payubiz.Admin');
			} elseif (!Tools::getValue('PAYUBIZ_KEY') && Tools::getValue('PAYUBIZ_SALT')) {
				$this->_postErrors[] = $this->trans('PayUBiz Key is required.', array(), 'Modules.Payubiz.Admin');
			} elseif (!Tools::getValue('PAYUBIZ_SALT') && Tools::getValue('PAYUBIZ_KEY')) {
				$this->_postErrors[] = $this->trans('PayUBiz Salt is required.', array(), 'Modules.Payubiz.Admin');
			}				
		}
	}

	private function _postProcess()
	{
		if (Tools::isSubmit('btnSubmit')) {
			Configuration::updateValue('PAYUBIZ_MODE', Tools::getValue('PAYUBIZ_MODE'));
			Configuration::updateValue('PAYUBIZ_KEY', Tools::getValue('PAYUBIZ_KEY'));
			Configuration::updateValue('PAYUBIZ_SALT', Tools::getValue('PAYUBIZ_SALT'));			
		}
		$this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Notifications.Success'));
	}
	
	public function getContent()
	{
		 $this->_html = '';

        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        }

        $this->_html .= $this->_displayCheck();
        $this->_html .= $this->renderForm();
        
		return $this->_html;
	}
	
	public function renderForm()
	{
		
		$options = array(
			array(
					'id_option' => 'production', 
					'name' => 'production' 
					),
				array(
					'id_option' => 'sandbox',
					'name' => 'sandbox'
					),
				);
			
		$fields_form = array(
			'form' => array(
					'legend' => array(
						'title' => $this->trans('PayUBiz details', array(), 'Modules.Payubiz.Admin'),
						'icon' => 'icon-envelope'
						),
					'input' => array(
						array(
							'type' => 'select',
							'label' => $this->trans('Gateway Mode', array(), 'Modules.Payubiz.Admin'),
							'name' => 'PAYUBIZ_MODE',
							'required' => true,
							'options' => array(
								'query' => $options,
								'id' => 'id_option', 
								'name' => 'name'
								)
							),						
						array(
								'type' => 'text',
								'label' => $this->trans('PayUBiz Key', array(), 'Modules.Payubiz.Admin'),
								'name' => 'PAYUBIZ_KEY',
								'required' => true
						),
						array(
								'type' => 'text',
								'label' => $this->trans('PayUBiz Salt', array(), 'Modules.Payubiz.Admin'),
								'name' => 'PAYUBIZ_SALT',
								'required' => true,
								'desc' => '<strong>Webhook URL: </strong> https://' . $_SERVER['SERVER_NAME'] . '/modules/payubiz/payu_webhook.php'
							),				
						),
					'submit' => array(
						'title' => $this->trans('Save', array(), 'Admin.Actions'),
						)
					),
				);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->id = (int)Tools::getValue('id_carrier');
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'btnSubmit';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFieldsValues(),
			);
        
		$this->fields_form = array();
		return $helper->generateForm(array($fields_form));
	}

	public function getConfigFieldsValues()
	{
		return array(
			'PAYUBIZ_MODE' => Tools::getValue('PAYUBIZ_MODE', Configuration::get('PAYUBIZ_MODE')),
			'PAYUBIZ_KEY' => Tools::getValue('PAYUBIZ_KEY', Configuration::get('PAYUBIZ_KEY')),
			'PAYUBIZ_SALT' => Tools::getValue('PAYUBIZ_SALT', Configuration::get('PAYUBIZ_SALT')),			
			);
	}

	private function _displayCheck()
	{
		return $this->display(__FILE__, './views/templates/hook/infos.tpl');
	}

	protected function payuInput()
	{
		// echo 1;die();
		global $smarty;

		// Retrieve context
		$context = Context::getContext();
		$cart = $context->cart;
		
		// Ensure cart is loaded properly
		if (!isset($cart) || empty($cart->id)) {
			if (!empty($context->cookie->id_cart)) {
				$cart = new Cart($context->cookie->id_cart);
			}
		}

		// Check if cart is still invalid
		if (empty($cart->id)) {
			die('Cart not found.');
		}
		// Check if essential details exist
		if (empty($cart->id_customer) || empty($cart->id_address_invoice)) {
			return []; // Exit early if customer or invoice address is missing
		}

		// Retrieve configuration values
		$udf5 = "Prestashop_v_1.7";
		$mode = Configuration::get('PAYUBIZ_MODE');
		$payu_key = Configuration::get('PAYUBIZ_KEY');
		$payu_salt = Configuration::get('PAYUBIZ_SALT');

		$merchantTxnId = rand(200, 3000) . '-' . $cart->id;
		
		// Retrieve customer details
		$customer = new Customer($cart->id_customer);
		
		$address = new Address($cart->id_address_invoice);
		
		if (empty($address->id)) {
			return []; // Exit if address is missing
		}

		// Retrieve state and country safely
		$state = new State($address->id_state);
		$country = new Country($address->id_country);

		// Retrieve customer and address information
		$firstName = !empty($address->firstname) ? $address->firstname : 'Guest';
		$lastName = !empty($address->lastname) ? $address->lastname : '';
		$zipcode = !empty($address->postcode) ? $address->postcode : '';
		$email = !empty($customer->email) ? $customer->email : 'guest@example.com';
		$phone = !empty($address->phone) ? $address->phone : '0000000000';
		$city = !empty($address->city) ? $address->city : '';
		$countryCode = !empty($country->iso_code) ? $country->iso_code : '';

		// Retrieve currency information
		$id_currency = (int) Configuration::get('PS_CURRENCY_DEFAULT');
		$currency = new Currency($id_currency);
		$currency_code = !empty($currency->iso_code) ? $currency->iso_code : 'INR';

		// Calculate order amount
		$orderAmount = number_format(Tools::convertPrice($cart->getOrderTotal(), $currency), 2, '.', '');
		
		// Define return URL
		$return_url = $context->link->getModuleLink($this->name, 'validation', [], true);
		
		// Set PayU action URL based on mode
		
		$action = ($mode == 'sandbox') ? 'https://test.payu.in/_payment' : 'https://secure.payu.in/_payment';
		
		$orderId = $cart->id;
		
		$productInfo = "Product Information";
		$Pg = 'CC';

		// Generate hash for PayU
		$hash_string = $payu_key . '|' . $orderId . '|' . $orderAmount . '|' . $productInfo . '|' . $firstName . '|' . $email . '|||||' . $udf5 . '||||||' . $payu_salt;
		$hash = hash('sha512', $hash_string);
		
		
		// Prepare values for PayU form
		
		$values = [
			'key' => $payu_key,
			'txnid' => $orderId,
			'amount' => $orderAmount,
			'productinfo' => $productInfo,
			'firstname' => $firstName,
			'Lastname' => $lastName,
			'Zipcode' => $zipcode,
			'email' => $email,
			'phone' => $phone,
			'surl' => $return_url,
			'furl' => $return_url,
			'curl' => $return_url,
			'Hash' => $hash,
			'Pg' => $Pg,
			'address1' => !empty($address->address1) ? $address->address1 : '',
			'address2' => !empty($address->address2) ? $address->address2 : '',
			'city' => $city,
			'country' => $countryCode,
			'udf5' => $udf5,
			'state' => !empty($state->id) ? State::getNameById($address->id_state) : '',
		];
		
		// Generate hidden form inputs
		$inputs = [];
		foreach ($values as $k => $v) {
			$inputs[$k] = [
				'name' => $k,
				'type' => 'hidden',
				'value' => $v,
			];
		}
		return $inputs;
	}
}
?>