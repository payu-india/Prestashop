<?php
// Load PrestaShop core
include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/../../init.php');

$logFile = _PS_MODULE_DIR_ . 'payubiz/logs/webhook.log';

// Logging function
function logMessage($message) {
    global $logFile;
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

// Capture headers
$headers = getallheaders();
logMessage("Headers: " . json_encode($headers));

// Capture raw POST data
$input = file_get_contents('php://input');
parse_str($input, $formData);

$data = !empty($formData) ? $formData : $_POST;
logMessage("Form Data: " . json_encode($data));

// Handle empty data
if (empty($data)) {
    http_response_code(400);
    echo json_encode(['error' => 'No data received']);
    exit;
}

// Retrieve PayUbiz keys
$merchant_key = Configuration::getGlobalValue('PAYUBIZ_KEY');
$salt = Configuration::getGlobalValue('PAYUBIZ_SALT');
$mode = Configuration::getGlobalValue('PAYUBIZ_MODE');

logMessage("Merchant Key: " . $merchant_key);
logMessage("Salt: " . $salt);
logMessage("Mode: " . $mode);

if (!$merchant_key || !$salt) {
    http_response_code(500);
    echo json_encode(['error' => 'Missing configuration values']);
    exit;
}

// ✅ Accessing transaction details
$txnid = $data['txnid'] ?? 'N/A';
$status = $data['status'] ?? 'N/A';
$amount = $data['amount'] ?? 'N/A';
$paymentId = $data['mihpayid'] ?? 'N/A';

// PayUbiz API endpoint
$command = "verify_payment";
$action = ($mode === 'sandbox') 
    ? 'https://test.payu.in/merchant/postservice' 
    : 'https://info.payu.in/merchant/postservice.php';

logMessage("API Action: " . $action);

// ✅ Correct Hash Generation
$hash_string = $merchant_key . '|' . $command . '|' . $txnid . '|' . $salt;
$hash = strtolower(hash("sha512", $hash_string));
logMessage("Generated Hash: " . $hash);

// ✅ Use Form-Encoded Data (NOT JSON)
$postData = http_build_query([
    'key' => $merchant_key,
    'command' => $command,
    'var1' => $txnid,
    'hash' => $hash
]);
logMessage("POST Data: " . $postData);

// ✅ Execute cURL request
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $action,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData,
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
]);

$response = curl_exec($ch);
$error = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($error) {
    logMessage("cURL error: $error");
    curl_close($ch);
    http_response_code(500);
    echo json_encode(['error' => "cURL error: $error"]);
    exit;
}

curl_close($ch);
logMessage("Raw Response: " . $response);
logMessage("HTTP Code: " . $httpCode);

// ✅ Handle serialized response properly
$transaction_data = @unserialize($response);

if ($transaction_data === false || !isset($transaction_data['transaction_details'][$txnid])) {
    logMessage("Invalid or empty response: " . json_encode($transaction_data));
    http_response_code(400);
    echo json_encode(['error' => 'Transaction not found or invalid response']);
    exit;
}

// ✅ Retrieve transaction details
$transactionDetails = $transaction_data['transaction_details'][$txnid] ?? [];
$transactionStatus = $transactionDetails['status'] ?? 'Not Found';
$order_id = Order::getIdByCartId($txnid);

logMessage("Order ID: " . json_encode($order_id));
logMessage("Transaction Status: " . $transactionStatus);
logMessage("Full Transaction Data: " . json_encode($transactionDetails));

if (!$order_id) {
    logMessage("Order not found for Cart ID: $txnid");
    http_response_code(404);
    echo json_encode(['Transaction ID' => $txnid, 'Status' => 'Error: Order not found']);
    exit;
}

// ✅ Update order status
if($transactionStatus != $status){
    $order = new Order($order_id);
    $history = new OrderHistory();
    $history->id_order = $order->id;

    // 🔥 Determine the order status and message
    if ($transactionStatus === 'failure') {
        $order_status = Configuration::get('PAYUBIZ_ID_ORDER_FAILED');
        $message = 'Order marked as failed.';
    } elseif ($transactionStatus === 'success') {
        $order_status = Configuration::get('PAYUBIZ_ID_ORDER_SUCCESS');
        $message = 'Order marked as successful.';
    } elseif ($transactionStatus === 'pending') {
        $order_status = (int) Configuration::get('PS_OS_WAITING_PAYMENT') ?: 14;
        $message = 'Order status updated to pending.';
    } else {
        $order_status = null;
        $message = 'Unknown status.';
    }




    if ($order_status) {
        $history->changeIdOrderState($order_status, $order->id);
        $history->addWithemail(true);

        // ✅ Store payment details if the transaction is successful
        if ($status === 'success') {
            $existingPayment = Db::getInstance()->getValue(
                'SELECT id_order_payment FROM ' . _DB_PREFIX_ . 'order_payment 
                 WHERE transaction_id = "' . pSQL($txnid) . '" 
                 AND order_reference = "' . pSQL($order->reference) . '"'
            );

            if (!$existingPayment) {
                $currency = new Currency($order->id_currency);
                $amount = (float)$transaction_data['transaction_details'][$txnid]['net_amount_debit'] ?? 0.00;

                $payment = new OrderPayment();
                $payment->order_reference = $order->reference;
                $payment->id_currency = (int)$currency->id;
                $payment->amount = $amount;
                $payment->payment_method = 'payubiz';
                $payment->transaction_id = $txnid;
                $payment->date_add = date('Y-m-d H:i:s');

                // ✅ Store Card Details
                $payment->card_number = $transaction_data['transaction_details'][$txnid]['cardnum'] ?? 'Not defined';
                $payment->card_type = $transaction_data['transaction_details'][$txnid]['card_type'] ?? 'Not defined';
                $payment->expiration_date = $transaction_data['transaction_details'][$txnid]['card_expiry'] ?? 'Not defined';
                $payment->cardholder_name = $transaction_data['transaction_details'][$txnid]['card_name'] ?? 'Not defined';

                $payment->save();

                // Link payment to order
                if (!$order->getOrderPayments()) {
                    $order->addOrderPayment($amount, 'payubiz', $txnid);
                }
            } else {
                PrestaShopLogger::addLog("PayUBiz: Duplicate payment detected for Transaction ID - " . $txnid, 1);
            }
        }
    }
}

// ✅ Log and send success response
logMessage("Order updated successfully.");
http_response_code(200);
echo json_encode(['Transaction ID' => $txnid, 'Status' => $transactionStatus, 'Message' => 'Order updated']);
?>
