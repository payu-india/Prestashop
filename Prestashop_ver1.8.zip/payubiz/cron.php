<?php
$_GET['fc'] = 'module';
$_GET['module'] = 'payubiz';
$_GET['controller'] = 'paymentstatus';

require_once dirname(__FILE__) . '/../../index.php';
