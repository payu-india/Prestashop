PayUbiz prestashop_1.6.1.1 Module v1.3 for Prestashop 1.6.1.1

-----------------------------------------------------------------------------

Copyright (c) 2011-2015 PayU india

LICENSE:
 
This PayUbiz payment module is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 3 of the License, or (at
your option) any later version.

This payment module is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
License for more details.

Please see http://www.opensource.org/licenses/ for a copy of the GNU Lesser
General Public License.


If You have any Issue Please Mail Us at tech@payu.in


******************************************************************************
*                                                                            *
*    Please see the URL below for all information concerning this module:    *
*                                                                            *
*                   http://www.payu.in                                       *
*                                                                            *
******************************************************************************